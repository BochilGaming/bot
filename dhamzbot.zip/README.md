# Kuhong-V4
Hanya Bot Biasa :v
# Kuhong-V4
Recode SC : Nurutomo

### FOR TERMUX USER
```bash
> pkg update && pkg upgrade
> pkg install git -y
> pkg install nodejs -y
> pkg install ffmpeg -y
> pkg install imagemagick -y
> pkg install unzip -y
> git clone https://github.com/RC047/Kuhong-V4
> cd Kuhong-V4
> unzip Kuhong-V4.zip
> npm i remove.bg && npm install
```
###### Run
```bash
> node . [<session name>] (session name is optional)
```

---------

### FOR WINDOWS/VPS/RDP USER
* Download And Install Git [`Click Here`](https://git-scm.com/downloads) <br>
* Download And Install NodeJS [`Click Here`](https://nodejs.org/en/download) <br>
* Download And Install FFMPEG [`Click Here`](https://ffmpeg.org/download.html) (don't forget to path) 
* Download And Install ImageMagick [`Click Here`](https://imagemagick.org/script/download.php) (if nulis want work,  checklist columns 1,2,3,5,6) 
```bash
> git clone https://github.com/RC047/Kuhong-V4
> cd Kuhong-V4
> unzip Kuhong-V4.zip
> npm i remove.bg && npm install
```
###### Run
```bash
> node index.js
```
--------------


## Fitur Bot

| BOT SYSTEM | YES
| :---------------------------------------------: | :-----------: |
|  Daftar|✅…|
| Anti Toxic|✅…|
| Anti Delete Pesan|✅…|


|  CREATOR  |                                           YES |
| :---------------------------------------------: | :-----------: |
| Sticker Maker|✅…|
| Sticker Gif Maker|✅…|
| Convert Sticker To Image|✅…|
| Harta Tahta|✅…|
| QR Code|✅…|
| Custom Harta Tahta|✅…|
| Glitchtext Maker|✅…|
| PornHub Logo Maker|✅…|
| Nulis Tugas|✅…|



| DOWNLOADER | YES |
| :-----------------: | :-------: |
| YTMP4|✅…|
| YTMP3|✅…|
| YT PLAY|✅…|


| EDUCATION | YES |
| :-----------------: | :-------: |
| Brainly|✅…|
| Belajar|✅…|


| IMAGE | YES |
| :-----------------: | :-------: |
| Anime|✅…|
| Foto Cewek|✅…|


| GROUP | YES |
| :-----------------: | :-------: |
| AFK|✅…|
| Anti Link|✅…|
| Link Group|✅…|
| Promote Member|✅…|
| Demote Member|✅…|
| Hide Tag|✅…|
| Add Member|✅…|
| Kick Member|✅…|
| Welcome & Bye Group|✅…|
| Delete Pesan|✅…|


| RANDOM | YES |
| :-----------------: | :-------: |
| Quotes|✅…|
| Pantun|✅…|
| Kata Bijak|✅…|
| Puisi|✅…|
| Syair|✅…|


| FUN | YES |
| :-----------------: | :-------: |
| Math|✅…|
| Slot Machine|✅…|
| Dadu|✅…|
| Truth or Dare|✅…|
| IQ Test|✅…|
| Alay|✅…|
| Hilih|✅…|


| OWNER | YES |
| :-----------------: | :-------: |
| Banned Member|✅…|
| Unbanned Member|✅…|
| Broadcast|✅…|
| Group Broadcast|✅…|
| Clear All Chat|✅…|


| PREMIUM MENU | YES |
| :-----------------: | :-------: |
| Jadi Bot|✅…|
| Join GC|✅…|


 TENTANG BOT | YES |
| :-----------------: | :-------: |
| Report|✅…|
| Info Bot|✅…|
| Status Bot|✅…|
| Donasi|✅…|
| Info Premium|✅…|

* Masih Banyak Lagi






##### Created By : [`Nurutomo`](https://GitHub.com/Nurutomo) 
##### Recode : [`RC047`](https://GitHub.com/RC047) 
