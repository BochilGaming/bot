let handler = m => m.reply('Wa`alaikumussalam')

handler.customPrefix = /assalamualaikum|Assalamualaikum/i
handler.command = new RegExp

module.exports = handler