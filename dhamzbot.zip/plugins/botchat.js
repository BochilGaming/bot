let handler = m => m.reply('Yaa Aku Disini??\n\nIngin Memulai Bot? Ketik !help atau !menu yaa ;)')

handler.customPrefix = /dhamz|Dhamz/i
handler.command = new RegExp

module.exports = handler